import { useMemo, useState } from 'react';
import { useFiscal } from '../state/fiscalContext';
import { ANIOS, INFLACION_A_2026, PRECIOS_REFERENCIA, SMI_ANUAL, calcularNomina } from '../engine/irpf';
import Figure from '../figures/Figure';
import ChartFrame from '../figures/ChartFrame';
import { Label } from '../figures/marks';
import { dec, eur } from '../utils/format';
import { round } from '../figures/scale';

const W = 880;
const FILA = 28;
const X0 = 62;
const XG = 84;
const PASO = 17;
const GRUPO = 5;
const HUECO = 8;

const AÑOS = ANIOS.filter(a => a <= PRECIOS_REFERENCIA.ultimoAnio);

/* Tres unidades concretas. Cada una con su glifo: se cuentan objetos, que es
   la forma más directa que existe de comparar dos años. */
const UNIDADES = {
  vivienda: {
    k: 'Metros de vivienda',
    glifo: 'cuadrado',
    singular: 'm² comprado',
    enTitulo: 'm² de vivienda',
    plural: 'm² de vivienda que compra tu neto de un año',
    precio: a => PRECIOS_REFERENCIA.venta[a],
    precioLabel: a => `${eur(PRECIOS_REFERENCIA.venta[a])}/m²`,
    nota: 'precio medio del metro cuadrado en venta, diciembre de cada año',
  },
  alquiler: {
    k: 'Meses de alquiler',
    glifo: 'casa',
    singular: 'mes de alquiler',
    enTitulo: 'meses de alquiler',
    plural: `meses de alquiler de un piso de ${PRECIOS_REFERENCIA.pisoM2} m² que paga tu neto de un año`,
    precio: a => PRECIOS_REFERENCIA.alquiler[a] * PRECIOS_REFERENCIA.pisoM2,
    precioLabel: a => `${eur(PRECIOS_REFERENCIA.alquiler[a] * PRECIOS_REFERENCIA.pisoM2)}/mes`,
    nota: `alquiler medio por metro cuadrado, diciembre de cada año, sobre un piso de ${PRECIOS_REFERENCIA.pisoM2} m²`,
  },
  smi: {
    k: 'Meses de salario mínimo',
    glifo: 'moneda',
    singular: 'mes de SMI',
    enTitulo: 'mensualidades del salario mínimo',
    plural: 'mensualidades del salario mínimo que cabe en tu neto de un año',
    precio: a => SMI_ANUAL[a] / 12,
    precioLabel: a => `${eur(SMI_ANUAL[a] / 12)}/mes`,
    nota: 'salario mínimo interprofesional del año, dividido en doce mensualidades',
  },
};

function Glifo({ tipo, x, y, lleno = 1 }) {
  const s = 11;
  const id = `${tipo}-${x}-${y}`;
  const color = 'var(--ink)';
  if (tipo === 'cuadrado') {
    return (
      <g>
        <rect x={round(x)} y={round(y - s / 2)} width={s} height={s} rx={1} fill="none" stroke={color} strokeWidth={0.9} />
        <rect x={round(x)} y={round(y - s / 2)} width={round(s * lleno)} height={s} rx={1} fill={color} />
      </g>
    );
  }
  if (tipo === 'casa') {
    return (
      <g>
        <path
          d={`M${round(x)} ${round(y + 5)} L${round(x)} ${round(y - 1)} L${round(x + 5.5)} ${round(y - 6)} L${round(x + 11)} ${round(y - 1)} L${round(x + 11)} ${round(y + 5)} Z`}
          fill={lleno >= 0.5 ? color : 'none'}
          stroke={color}
          strokeWidth={0.9}
          strokeLinejoin="round"
        />
      </g>
    );
  }
  return (
    <g>
      <circle cx={round(x + 5.5)} cy={round(y)} r={5} fill={lleno >= 0.5 ? color : 'none'} stroke={color} strokeWidth={0.9} />
      <title>{id}</title>
    </g>
  );
}

/**
 * FIG. 17 — TU SUELDO, MEDIDO EN COSAS.
 *
 * El neto real ya está en euros constantes, pero un euro constante sigue
 * siendo una abstracción: el IPC general mezcla la vivienda con los
 * electrodomésticos. Esta figura cambia el denominador por algo que se puede
 * señalar con el dedo —metros cuadrados, mensualidades de alquiler, salarios
 * mínimos— y cuenta cuántos caben en el mismo sueldo, año por año.
 *
 * Lo que mueve cada fila son dos fuerzas a la vez: lo que cambió la fiscalidad
 * (el neto) y lo que cambió el precio de esa cosa. La nota lo dice, porque
 * atribuirlo todo a los impuestos sería mentir.
 */
export default function EnCosas({ bruto2026 }) {
  const { anio, opts } = useFiscal();
  const [unidad, setUnidad] = useState('vivienda');
  const [tip, setTip] = useState(null);

  const u = UNIDADES[unidad];

  const serie = useMemo(
    () =>
      AÑOS.map(a => {
        const inf = INFLACION_A_2026[a];
        const n = calcularNomina(bruto2026 / inf, a, opts);
        const netoNominal = n.salarioNeto;      // euros de ese año
        const precio = u.precio(a);             // euros de ese año
        return { anio: a, netoNominal, precio, unidades: netoNominal / precio };
      }),
    [bruto2026, opts, u]
  );

  const primero = serie[0];
  const ultimo = serie[serie.length - 1];
  const H = serie.length * FILA + 86;
  const maxU = Math.max(...serie.map(s => s.unidades));
  const px = i => XG + i * PASO + Math.floor(i / GRUPO) * HUECO;

  return (
    <Figure
      id="18"
      title={`El mismo sueldo daba para ${dec(primero.unidades, 1)} ${u.enTitulo} en ${primero.anio} y para ${dec(ultimo.unidades, 1)} en ${ultimo.anio}`}
      sub={`${eur(bruto2026)} constantes de 2026 · ${u.plural} · ${u.nota}`}
      legend={`Cada figura es ${u.singular === 'm² comprado' ? 'un metro cuadrado' : `${u.singular}`} · van de cinco en cinco para poder contarlas · la última va a medias cuando la cuenta no es exacta`}
      source={`Fuente · ${unidad === 'smi' ? 'BOE — SMI de cada ejercicio' : PRECIOS_REFERENCIA.fuente} · cálculo propio`}
      note="Cada fila se mueve por dos motivos a la vez: lo que la fiscalidad dejó en tu bolsillo ese año y lo que costaba esa cosa ese año. El sueldo de partida es siempre el mismo en poder adquisitivo general; lo que cambia es el precio relativo de lo que compras. La serie llega hasta 2025 porque es el último ejercicio cerrado con precios publicados."
      summary={serie.map(s => `${s.anio}: ${dec(s.unidades, 1)}`).join('; ')}
    >
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'center', marginBottom: 16 }}>
        <span className="fs-seg">
          {Object.entries(UNIDADES).map(([k, v]) => (
            <button key={k} type="button" aria-pressed={unidad === k} onClick={() => setUnidad(k)}>
              {v.k}
            </button>
          ))}
        </span>
        <span className="fs-note" style={{ margin: 0 }}>
          ¿Cuántos caben en tu sueldo neto de un año?
        </span>
      </div>

      <ChartFrame viewBox={`0 0 ${W} ${H}`} tip={tip} scroll minWidth={720} label="El sueldo medido en cosas">
        <Label x={XG} y={22} size={9} color="var(--ink-5)" mono>
          CADA FIGURA = 1 {u.singular.toUpperCase()}
        </Label>
        <Label x={W - 104} y={22} size={8.5} color="var(--ink-5)" anchor="end" mono>
          CUÁNTOS
        </Label>
        <Label x={W - 2} y={22} size={8.5} color="var(--ink-5)" anchor="end" mono>
          PRECIO
        </Label>

        {serie.map((s, fila) => {
          const y = 48 + fila * FILA;
          const enteros = Math.floor(s.unidades);
          const resto = s.unidades - enteros;
          const esSel = s.anio === anio;
          const esMax = Math.abs(s.unidades - maxU) < 1e-9;

          return (
            <g key={s.anio} className="fs-group">
              <text
                x={X0}
                y={y + 3.5}
                fontSize={10.5}
                fontWeight={esSel ? 800 : 600}
                textAnchor="end"
                fill={esSel ? 'var(--signal)' : 'var(--ink-4)'}
                className="fs-t-stamp"
              >
                {s.anio}
              </text>

              {Array.from({ length: enteros }, (_, i) => (
                <Glifo key={i} tipo={u.glifo} x={px(i)} y={y} />
              ))}
              {resto > 0.08 && <Glifo tipo={u.glifo} x={px(enteros)} y={y} lleno={resto} />}

              <text
                x={W - 104}
                y={y + 3.5}
                fontSize={12}
                fontWeight={esSel || esMax ? 800 : 600}
                textAnchor="end"
                fill={esSel ? 'var(--signal)' : 'var(--ink)'}
                className="num"
              >
                {dec(s.unidades, 1)}
              </text>
              <text
                x={W - 2}
                y={y + 3.5}
                fontSize={10}
                textAnchor="end"
                fill="var(--ink-4)"
                className="num"
              >
                {u.precioLabel(s.anio)}
              </text>

              <rect
                className="fs-hit"
                x={0}
                y={y - FILA / 2}
                width={W}
                height={FILA}
                onMouseEnter={() =>
                  setTip({
                    vx: px(Math.max(1, enteros)),
                    vy: y,
                    title: `${dec(s.unidades, 1)} ${u.singular}s`,
                    sub: `${s.anio} · con tu neto de ese año`,
                    rows: [
                      ['Neto de ese año', eur(s.netoNominal), 'var(--signal)'],
                      ['Precio', u.precioLabel(s.anio)],
                      [`Frente a ${primero.anio}`, `${s.unidades >= primero.unidades ? '+' : '−'}${dec(Math.abs(s.unidades - primero.unidades), 1)}`],
                    ],
                  })
                }
                onMouseLeave={() => setTip(null)}
              >
                <title>{`${s.anio} — ${dec(s.unidades, 1)} ${u.singular}s`}</title>
              </rect>
            </g>
          );
        })}

        <Label x={XG} y={H - 26} size={9} color="var(--ink-5)" mono>
          ← CADA HUECO SEPARA CINCO
        </Label>
      </ChartFrame>
    </Figure>
  );
}
